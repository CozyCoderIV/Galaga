package com.company;

import com.company.display.Window;
import com.company.display.*;

public class Main
{   public static void main(String[] args)
    {  // write your code here
       Window ww = new Window("Galaga V", 900, 800);
    }
}
